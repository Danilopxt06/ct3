extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
@onready var character_body_2d: CharacterBody2D = $"."


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if (velocity.x > 1 || velocity.x < -1):
		$Sprite2D.animation = "running"
	else:
		$Sprite2D.animation = "default"
	
	if not is_on_floor():
		velocity += get_gravity() * delta
		$Sprite2D.animation = "jumping"
	
	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	
	if velocity.x < 0:
		Sprite2D.flip_h = true
	else:
		Sprite2D.flip_h = false
